var name=prompt("Enter your name");
var age=prompt("Enter age");
console.log("Hello "+name);
console.log("Your age is "+age);